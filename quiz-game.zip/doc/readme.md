# Quiz Webapp

## Flavio:
* made the backend and routes for the frontend and basic ejs for failures.

### Salazar
* made front end fixed some backend logic

### Apostos
* Helped with front end logic and design.